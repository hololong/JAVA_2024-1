/*
 * 작성일 : 2024년 3월 8일
 * 작성자 : 컴퓨터소프트웨어공학부 202195039 임서윤
 * 설명 : 첫 번째 자바 프로그램
 */
public class first {

	public static void main(String[] args) {
		System.out.println("안녕하세요.");
		System.out.print("임서윤입니다.");
		System.out.println("반갑습니다." + "첫 번째 자바 프로그램입니다.");
	}

}
